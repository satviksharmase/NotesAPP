package com.example.NotesApp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DataBaseHelper extends SQLiteOpenHelper {

    Context context;

    public DataBaseHelper(@Nullable Context context) {
        super(context, Utils.DatabaseName, null, Utils.DatabaseVersion);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String query = "CREATE TABLE " + Utils.TableName +
                " (" + Utils.ColumnId + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Utils.ColumnHeading + " TEXT, " +
                Utils.Columntext + " TEXT);";

        db.execSQL(query);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Utils.TableName);
        onCreate(db);
    }

    void Add_Note(String heading,String text)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Utils.ColumnHeading, heading);
        contentValues.put(Utils.Columntext, text);

        long resultValue = db.insert(Utils.TableName,null,contentValues);
        if (resultValue == -1)
        {
            Toast.makeText(context,"FAILED!", Toast.LENGTH_SHORT).show();

        }

        else
        {
            Toast.makeText(context, "SUCCESSFUL!", Toast.LENGTH_SHORT).show();
        }
    }

    Cursor Read_Note()
    {
        String query = "SELECT * FROM " + Utils.TableName;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if(db!= null)
        {
            cursor = db.rawQuery(query,null);
        }
        return cursor;
    }

    void Update_Note(String heading, String text, String id)
    {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues  = new ContentValues();
        contentValues.put(Utils.ColumnHeading,heading);
        contentValues.put(Utils.Columntext,text);

        long result = database.update(Utils.TableName,contentValues,"id=?",new String[]{id});
        if(result == -1)
        {
            Toast.makeText(context, "FAILED!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(context, "SUCCESSFUL!", Toast.LENGTH_SHORT).show();
        }
    }

    void Delete_Note(String id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        long result1 = db.delete(Utils.TableName,"id=?", new String[]{id});

        if(result1 == -1)
        {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(context, "Deleted Successfully", Toast.LENGTH_SHORT).show();
        }
    }
}

package com.example.NotesApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity4 extends AppCompatActivity {

    EditText heading,text;
    Button update, delete;
    String id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        heading = findViewById(R.id.textView);
        text = findViewById(R.id.textView2);
        update = findViewById(R.id.Button5);
        delete = findViewById(R.id.Button6);

        Intent i = getIntent();
        heading.setText(i.getStringExtra(""));
        text.setText(i.getStringExtra("text"));
        id = i.getStringExtra("id");

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!TextUtils.isEmpty(heading.getText().toString()) && !TextUtils.isEmpty(text.getText().toString()))
                {
                    DataBaseHelper db = new DataBaseHelper(MainActivity4.this);
                    db.Update_Note(heading.getText().toString(),text.getText().toString(),id);

                    Intent i = new Intent(MainActivity4.this, MainActivity3.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    finish();
                }
                else
                {
                    Toast.makeText(MainActivity4.this, "EMPTY!", Toast.LENGTH_SHORT).show();
                }
            }
        });


        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DataBaseHelper db = new DataBaseHelper(MainActivity4.this);
                db.Delete_Note(id);
                finish();
            }
        });

    }
}
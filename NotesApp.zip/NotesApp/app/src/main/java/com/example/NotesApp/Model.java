package com.example.NotesApp;

public class Model {

    String heading;
    String text;
    String id;

    public Model(String id, String heading, String text) {
        this.heading = heading;
        this.text = text;
        this.id = id;
    }

    public String getHeading() {
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}

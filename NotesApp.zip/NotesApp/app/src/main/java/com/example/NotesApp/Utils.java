package com.example.NotesApp;

public class Utils {
    public static final String DatabaseName = "Notes";
    public static final int DatabaseVersion = 1;
    public static final String TableName = "notes";
    public static final String ColumnId = "id";
    public static final String ColumnHeading = "heading";
    public static final String Columntext = "text";
}


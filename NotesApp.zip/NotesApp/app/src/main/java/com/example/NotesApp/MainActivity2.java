package com.example.NotesApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    EditText heading, text;
    Button Save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        heading = findViewById(R.id.editTextTextPersonName2);
        text = findViewById(R.id.editTextTextMultiLine);
        Save = findViewById(R.id.button4);


        Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!TextUtils.isEmpty(heading.getText().toString()) && !TextUtils.isEmpty(text.getText().toString()))
                {
                    DataBaseHelper db = new DataBaseHelper(MainActivity2.this);
                    db.Add_Note(heading.getText().toString(),text.getText().toString());

                    Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(MainActivity2.this, "EMPTY!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}